// Panel UI controller for AICraft Companion extension
import { sendMessage, loadChatHistory, saveChatHistory } from './chat.js';

let agentData = null;
let chatHistory = [];

// Initialize panel
async function initPanel() {
  // Load agent data from storage
  const data = await chrome.storage.local.get(['agentData', 'chatHistory']);
  agentData = data.agentData;
  chatHistory = data.chatHistory || [];

  // Populate UI with agent info
  document.getElementById('agent-name').textContent = agentData.name;
  document.getElementById('agent-avatar').src = agentData.avatar_url;

  // Load chat history
  displayChatHistory();

  // Set up event listeners
  const sendButton = document.getElementById('send-button');
  const messageInput = document.getElementById('message-input');

  sendButton.addEventListener('click', handleSendMessage);
  messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  });

  // Focus input
  messageInput.focus();
}

// Display chat history
function displayChatHistory() {
  const chatArea = document.getElementById('chat-area');
  chatArea.innerHTML = '';

  if (chatHistory.length === 0) {
    addSystemMessage('Start chatting with your AICraft companion!');
  } else {
    chatHistory.forEach(msg => {
      addMessageToUI(msg.role, msg.content);
    });
  }

  scrollToBottom();
}

// Handle send message
async function handleSendMessage() {
  const input = document.getElementById('message-input');
  const sendButton = document.getElementById('send-button');
  const message = input.value.trim();

  if (!message) return;

  // Disable input while processing
  input.disabled = true;
  sendButton.disabled = true;

  // Add user message to UI
  addMessageToUI('user', message);
  input.value = '';

  // Add to history
  chatHistory.push({
    role: 'user',
    content: message,
    timestamp: new Date().toISOString()
  });

  try {
    // Send to chat handler and get response
    const response = await sendMessage(message, agentData);

    // Add agent response to UI
    addMessageToUI('agent', response);

    // Add to history
    chatHistory.push({
      role: 'agent',
      content: response,
      timestamp: new Date().toISOString()
    });

    // Save history
    await chrome.storage.local.set({ chatHistory });

  } catch (error) {
    console.error('Error sending message:', error);
    addSystemMessage('Error: Could not get response. Please try again.');
  } finally {
    // Re-enable input
    input.disabled = false;
    sendButton.disabled = false;
    input.focus();
  }
}

// Add message to UI
function addMessageToUI(role, content) {
  const chatArea = document.getElementById('chat-area');
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${role}`;
  messageDiv.textContent = content;
  chatArea.appendChild(messageDiv);
  scrollToBottom();
}

// Add system message
function addSystemMessage(content) {
  const chatArea = document.getElementById('chat-area');
  const messageDiv = document.createElement('div');
  messageDiv.className = 'message system';
  messageDiv.textContent = content;
  chatArea.appendChild(messageDiv);
  scrollToBottom();
}

// Scroll to bottom of chat
function scrollToBottom() {
  const chatArea = document.getElementById('chat-area');
  chatArea.scrollTop = chatArea.scrollHeight;
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initPanel);
