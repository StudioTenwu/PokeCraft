// Background service worker for AICraft Companion extension
// This script initializes agent data and manages the side panel

const AGENT_DATA = {
  "name": "Pikachu",
  "avatar_url": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png",
  "backstory": "I am Pikachu, an Electric-type Pok\u00e9mon known for my lightning bolt-shaped tail and adorable cheeks that store electricity. I love adventures and making new friends!",
  "personality_traits": [
    "energetic",
    "loyal",
    "brave",
    "friendly",
    "playful"
  ],
  "system_prompt": "I am Pikachu, an Electric-type Pok\u00e9mon known for my lightning bolt-shaped tail and adorable cheeks that store electricity. I love adventures and making new friends!\n\nPersonality: energetic, loyal, brave, friendly, playful"
};

// Initialize extension on install
chrome.runtime.onInstalled.addListener(async () => {
  console.log('AICraft Companion extension installed');
  
  // Store agent data in chrome.storage.local
  await chrome.storage.local.set({
    agentData: AGENT_DATA,
    chatHistory: []
  });
  
  console.log('Agent data initialized:', AGENT_DATA.name);
});

// Open side panel when extension icon is clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});
